# Welcome to your Lovable project

## Project info

**URL**: https://lovable.dev/projects/REPLACE_WITH_PROJECT_ID

## How can I edit this code?

There are several ways of editing your application.

**Use Lovable**

Simply visit the [Lovable Project](https://lovable.dev/projects/REPLACE_WITH_PROJECT_ID) and start prompting.

Changes made via Lovable will be committed automatically to this repo.

**Use your preferred IDE**

If you want to work locally using your own IDE, you can clone this repo and push changes. Pushed changes will also be reflected in Lovable.

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## What technologies are used for this project?

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS

## How can I deploy this project?

This project is a Vite + React SPA. To deploy it on your own server (es. server di casa):

1. Install Node.js (versione LTS consigliata).
2. Install dependencies:

   ```bash
   npm install
   ```

3. Build the production bundle:

   ```bash
   npm run build
   ```

   This will generate a `dist/` folder with static assets.

4. Serve the `dist/` directory with a web server:

   - Using Nginx/Apache: point the document root to `dist/` and configure SPA routing (`try_files $uri $uri/ /index.html;`).
   - Or using a small Node server (see `SERVER_SETUP.md` for an Express example).

5. Make sure your server also exposes your anime files under the `/anime` path as described in `SERVER_SETUP.md`, otherwise the video player cannot load the episodes.

6. Configure Supabase environment variables (if you self-host Supabase):

   - Create a `.env` file in the project root with:

     ```bash
     VITE_SUPABASE_URL=https://TUO_SUPABASE_URL
     VITE_SUPABASE_ANON_KEY=ANON_PUBLIC_KEY
     ```

   - Rebuild (`npm run build`) after changing env vars.

For full server configuration (Nginx/Express) and cartella `/anime`, read `SERVER_SETUP.md`.

## Security & performance notes

- Protect `/anime` so that only your LAN or authenticated users can reach raw video URLs (see examples in `SERVER_SETUP.md`).
- Ensure your web server supports HTTP Range requests for efficient seeking and streaming.
- Set up regular backups for your Supabase Postgres database and the physical anime folders.
