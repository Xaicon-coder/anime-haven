-- Core Supabase schema for Anime Haven

-- Users are managed by Supabase auth. We reference auth.users via user_id UUID.

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  avatar_url text,
  language text default 'it',
  parental_level int default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.profiles_devices (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  device_id text not null,
  device_type text,
  last_seen timestamptz default now(),
  unique (user_id, device_id)
);

create table if not exists public.profiles_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  audio_language text default 'it',
  subtitle_language text default 'it',
  theme text default 'dark',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Anime catalog

create table if not exists public.anime (
  id text primary key, -- e.g. 'dr-stone-s4'
  title text not null,
  description text not null,
  cover text not null,
  banner text not null,
  year int,
  status text, -- In corso / Completato
  folder_name text not null, -- maps to Anime.folderName
  rating numeric(3,1),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.seasons (
  id text not null,
  anime_id text not null references public.anime(id) on delete cascade,
  number int not null,
  title text not null,
  folder_name text not null, -- maps to Season.folderName
  file_prefix text,
  file_suffix text,
  next_air_date date,
  primary key (anime_id, id)
);

create table if not exists public.episodes (
  id text not null,
  anime_id text not null,
  season_id text not null,
  number int not null,
  title text not null,
  duration_minutes int,
  thumbnail text,
  file_name text,
  air_date date,
  primary key (anime_id, season_id, id),
  foreign key (anime_id, season_id) references public.seasons(anime_id, id) on delete cascade
);

-- Watch progress / history

create table if not exists public.watch_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  anime_id text not null,
  season_id text not null,
  episode_id text not null,
  current_time_seconds int not null,
  duration_seconds int not null,
  updated_at timestamptz default now(),
  primary key (user_id, anime_id, season_id, episode_id)
);

create table if not exists public.watchlist (
  user_id uuid not null references auth.users(id) on delete cascade,
  anime_id text not null references public.anime(id) on delete cascade,
  created_at timestamptz default now(),
  primary key (user_id, anime_id)
);

create table if not exists public.watched_episodes (
  user_id uuid not null references auth.users(id) on delete cascade,
  anime_id text not null,
  season_id text not null,
  episode_id text not null,
  completed_at timestamptz default now(),
  primary key (user_id, anime_id, season_id, episode_id),
  foreign key (anime_id, season_id, episode_id)
    references public.episodes(anime_id, season_id, id) on delete cascade
);

create table if not exists public.history (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  anime_id text not null,
  season_id text not null,
  episode_id text not null,
  watched_seconds int not null,
  finished boolean default false,
  last_watch_at timestamptz default now()
);

-- Skip segments for intro/outro/recap

create table if not exists public.skip_segments (
  id bigserial primary key,
  anime_id text not null,
  season_id text not null,
  episode_id text not null,
  type text not null check (type in ('intro', 'outro', 'recap')),
  start_seconds int not null,
  end_seconds int not null,
  unique (anime_id, season_id, episode_id, type)
);

-- Ratings & comments

create table if not exists public.ratings (
  user_id uuid not null references auth.users(id) on delete cascade,
  anime_id text not null references public.anime(id) on delete cascade,
  score int not null check (score between 1 and 10),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  primary key (user_id, anime_id)
);

create table if not exists public.comments (
  id bigserial primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  anime_id text not null references public.anime(id) on delete cascade,
  season_id text,
  episode_id text,
  parent_id bigint references public.comments(id) on delete cascade,
  content text not null,
  created_at timestamptz default now()
);

-- Collections

create table if not exists public.collections (
  id bigserial primary key,
  slug text not null unique,
  title text not null,
  description text,
  created_at timestamptz default now()
);

create table if not exists public.collection_items (
  collection_id bigint not null references public.collections(id) on delete cascade,
  anime_id text not null references public.anime(id) on delete cascade,
  position int default 0,
  primary key (collection_id, anime_id)
);

-- Basic Row Level Security (RLS) recommendations (enable in Supabase UI and adapt as needed):
--   - profiles / profiles_devices / profiles_preferences: user_id = auth.uid()
--   - watch_progress / watchlist / watched_episodes / history / ratings / comments: user_id = auth.uid()

