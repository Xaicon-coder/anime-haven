## Struttura cartelle per gli anime

Perché il player funzioni, i file video devono essere esposti dal tuo server con percorsi come:

- `/anime/<Anime.folderName>/<Season.folderName>/<VideoFile>.mp4`

Esempio per **Dr. Stone: Science Future parte 1**:

- `Anime.folderName = "Dr. Stone ITA"`
- `Season.folderName = "Dr. Stone: Science Future parte 1"`
- File sul disco:
  - `DrStone4_Ep_01_ITA.mp4`
  - `DrStone4_Ep_02_ITA.mp4`
  - …

Struttura cartelle consigliata sul server (Windows o Linux):

- `D:\DATA\anime\Dr. Stone ITA\Dr. Stone: Science Future parte 1\DrStone4_Ep_01_ITA.mp4`
- `D:\DATA\anime\Dr. Stone ITA\Dr. Stone: Science Future parte 1\DrStone4_Ep_02_ITA.mp4`
- ecc.

Il web server dovrà esporre questa cartella radice come `/anime`.

---

## Configurazione Nginx (consigliata)

Esempio di configurazione per un server Nginx su cui:

- i file degli anime stanno in `D:/DATA/anime` (su Windows) o `/srv/anime` (su Linux)
- l’app React buildata sta nella cartella `dist/`

```nginx
server {
    listen 80;
    server_name TUO_DOMINIO_O_IP;

    # App frontend buildata da Vite
    root  /percorso/assoluto/al/progetto/dist;
    index index.html;

    # Route SPA (React Router)
    location / {
        try_files $uri $uri/ /index.html;
    }

    # File video e sottotitoli
    location /anime/ {
        # Scegli **uno** dei due alias in base al tuo sistema:
        # Windows:
        # alias D:/DATA/anime/;
        # Linux:
        # alias /srv/anime/;

        # Abilita range requests per lo streaming/seek
        add_header Accept-Ranges bytes;

        # Solo il dominio della tua app può incorporare i video
        add_header Access-Control-Allow-Origin https://TUO_DOMINIO_APP;
        add_header Access-Control-Allow-Credentials true;

        # (Opzionale) Proteggi l'accesso con basic auth o whitelist IP LAN
        # allow 192.168.0.0/16;
        # deny all;
        # auth_basic "Anime Haven";
        # auth_basic_user_file /etc/nginx/.htpasswd;
    }
}
```

> Nota: dopo ogni modifica alla configurazione ricordati di riavviare Nginx.

---

## Configurazione di esempio con Node/Express

Se preferisci non usare Nginx, puoi servire i file con un piccolo server Node:

```bash
npm install express
```

```ts
// server/fileserver.ts
import express from "express";
import path from "path";

const app = express();

// Percorso fisico dove tieni gli anime
const ANIME_ROOT = process.env.ANIME_ROOT || "D:/DATA/anime";

// Statico /anime -> cartella fisica
app.use(
  "/anime",
  express.static(ANIME_ROOT, {
    acceptRanges: true, // abilita HTTP Range
  })
);

// Fallback SPA per il frontend buildato
const distDir = path.join(__dirname, "..", "dist");
app.use(express.static(distDir));
app.get("*", (_req, res) => {
  res.sendFile(path.join(distDir, "index.html"));
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => {
  console.log(`Server avviato su http://localhost:${port}`);
});
```

Per avviarlo dopo il build Vite:

```bash
npm run build
node server/fileserver.js
```

Puoi usare `pm2` o `nssm`/servizi di Windows per tenerlo sempre attivo.

---

## Verifica rapida che `/anime` funzioni

1. Copia sul server alcuni file, ad esempio:
   - `D:/DATA/anime/Dr. Stone ITA/Dr. Stone: Science Future parte 1/DrStone4_Ep_01_ITA.mp4`
2. Apri nel browser l’URL:
   - `http://TUO_SERVER/anime/Dr%20Stone%20ITA/Dr%20Stone:%20Science%20Future%20parte%201/DrStone4_Ep_01_ITA.mp4`
3. Se il video parte o viene scaricato, la configurazione `/anime` è corretta e l’app potrà riprodurlo tramite `getVideoPath`.

