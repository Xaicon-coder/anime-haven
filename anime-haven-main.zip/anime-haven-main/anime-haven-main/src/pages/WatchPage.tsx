import { useParams, Link } from "react-router-dom";
import { ChevronLeft, ChevronRight } from "lucide-react";
import Navbar from "@/components/Navbar";
import VideoPlayer from "@/components/VideoPlayer";
import { useAnimeById } from "@/hooks/useAnimeApi";
import { useComments } from "@/hooks/useRatingsComments";
import { useAuth } from "@/hooks/useAuth";

const WatchPage = () => {
  const { animeId, seasonId, episodeId } = useParams();
  const { anime } = useAnimeById(animeId || "");
  const { user } = useAuth();

  const season = anime?.seasons.find((s) => s.id === seasonId);
  const episode = season?.episodes.find((e) => e.id === episodeId);
  const episodeIndex = season?.episodes.findIndex((e) => e.id === episodeId) ?? -1;
  const prevEp = episodeIndex > 0 ? season?.episodes[episodeIndex - 1] ?? null : null;
  const nextEp = season && episodeIndex < season.episodes.length - 1 ? season.episodes[episodeIndex + 1] : null;

  const { comments, isLoading: commentsLoading, addComment, canComment } = useComments(
    anime?.id,
    episode?.id
  );
  const [newComment, setNewComment] = useState("");

  if (!anime || !season || !episode) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Navbar />
        <div className="text-center px-4">
          <h1 className="text-xl sm:text-2xl font-display font-bold text-foreground mb-2">Episodio non trovato</h1>
          <Link to="/" className="text-primary hover:underline text-sm">Torna alla home</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-16">
        <VideoPlayer
          anime={anime}
          season={season}
          episode={episode}
          prevEp={prevEp}
          nextEp={nextEp}
        />

        {/* Info sotto il video */}
        <div className="max-w-[1800px] mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4 mb-4 sm:mb-6">
            <div>
              <h1 className="text-lg sm:text-xl lg:text-2xl xl:text-3xl font-display font-bold text-foreground">{anime.title}</h1>
              <p className="text-muted-foreground text-xs sm:text-sm lg:text-base mt-0.5 sm:mt-1">
                Stagione {season.number} • Episodio {episode.number} - {episode.title}
              </p>
            </div>
            <div className="flex items-center gap-2 sm:gap-3">
              {prevEp && (
                <Link to={`/watch/${anime.id}/${season.id}/${prevEp.id}`}
                  className="inline-flex items-center gap-1 bg-secondary hover:bg-secondary/80 text-secondary-foreground px-3 sm:px-4 lg:px-5 py-1.5 sm:py-2 lg:py-2.5 rounded-lg text-xs sm:text-sm lg:text-base font-medium transition-colors">
                  <ChevronLeft size={14} className="sm:w-4 sm:h-4 lg:w-5 lg:h-5" /> Precedente
                </Link>
              )}
              {nextEp && (
                <Link to={`/watch/${anime.id}/${season.id}/${nextEp.id}`}
                  className="inline-flex items-center gap-1 bg-primary hover:bg-primary/90 text-primary-foreground px-3 sm:px-4 lg:px-5 py-1.5 sm:py-2 lg:py-2.5 rounded-lg text-xs sm:text-sm lg:text-base font-medium transition-colors">
                  Prossimo <ChevronRight size={14} className="sm:w-4 sm:h-4 lg:w-5 lg:h-5" />
                </Link>
              )}
            </div>
          </div>

          <h3 className="text-xs sm:text-sm lg:text-base font-display font-semibold text-muted-foreground uppercase tracking-wider mb-2 sm:mb-3">
            Altri episodi
          </h3>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 2xl:grid-cols-10 gap-2 sm:gap-3 mb-6">
            {season.episodes.map((ep) => (
              <Link key={ep.id} to={`/watch/${anime.id}/${season.id}/${ep.id}`}
                className={`rounded-lg p-2 sm:p-3 lg:p-4 text-xs sm:text-sm lg:text-base font-medium transition-all border text-center focus:outline-none focus:ring-2 focus:ring-primary ${
                  ep.id === episodeId
                    ? "bg-primary/15 border-primary/40 text-primary"
                    : "bg-secondary border-border text-muted-foreground hover:text-foreground hover:border-primary/20"
                }`}>
                Ep. {ep.number}
              </Link>
            ))}
          </div>

          {/* Commenti episodio */}
          <div className="border-t border-border pt-4 mt-2">
            <h3 className="text-xs sm:text-sm lg:text-base font-display font-semibold text-foreground mb-2">
              Commenti dell'episodio
            </h3>

            {canComment ? (
              <form
                className="mb-4 space-y-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  const trimmed = newComment.trim();
                  if (!trimmed) return;
                  addComment(trimmed);
                  setNewComment("");
                }}
              >
                <textarea
                  className="w-full min-h-[50px] rounded-md bg-secondary text-xs sm:text-sm text-foreground px-3 py-2 outline-none border border-border focus:border-primary resize-y"
                  placeholder="Scrivi cosa ne pensi di questo episodio (senza spoiler pesanti)..."
                  maxLength={400}
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                />
                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-muted-foreground">
                    {newComment.length}/400
                  </span>
                  <button
                    type="submit"
                    className="inline-flex items-center px-3 py-1.5 rounded-md bg-primary text-primary-foreground text-xs sm:text-sm font-medium hover:bg-primary/90"
                  >
                    Pubblica
                  </button>
                </div>
              </form>
            ) : (
              <p className="text-[10px] sm:text-xs text-muted-foreground mb-3">
                Accedi per commentare l'episodio.
              </p>
            )}

            <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
              {commentsLoading && (
                <p className="text-[10px] text-muted-foreground">Caricamento commenti...</p>
              )}
              {!commentsLoading && comments.length === 0 && (
                <p className="text-[10px] text-muted-foreground">
                  Nessun commento ancora per questo episodio.
                </p>
              )}
              {comments.map((c) => (
                <div
                  key={c.id}
                  className="rounded-md border border-border bg-secondary/40 px-3 py-1.5"
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-[11px] font-medium text-foreground">
                      {c.username || "Utente anonimo"}
                    </span>
                    <span className="text-[9px] text-muted-foreground">
                      {new Date(c.createdAt).toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-[11px] sm:text-xs text-foreground whitespace-pre-wrap break-words">
                    {c.content}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WatchPage;
