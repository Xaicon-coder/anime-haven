import { useState, useEffect, useCallback } from 'react';
import { supabase, isSupabaseConfigured } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';

const WATCHLIST_KEY = 'anistream-watchlist';
const WATCHED_KEY = 'anistream-watched-episodes';

function getStoredList(key: string): string[] {
  try {
    return JSON.parse(localStorage.getItem(key) || '[]');
  } catch {
    return [];
  }
}

function setStoredList(key: string, list: string[]) {
  localStorage.setItem(key, JSON.stringify(list));
}

function getStoredSet(key: string): Record<string, string[]> {
  try {
    return JSON.parse(localStorage.getItem(key) || '{}');
  } catch {
    return {};
  }
}

function setStoredSet(key: string, data: Record<string, string[]>) {
  localStorage.setItem(key, JSON.stringify(data));
}

// ── Watchlist (anime da vedere) ──
export function useWatchlist() {
  const { user } = useAuth();
  const [watchlist, setWatchlist] = useState<string[]>(() => getStoredList(WATCHLIST_KEY));

  // Carica watchlist da Supabase quando l'utente è loggato
  useEffect(() => {
    if (!user || !isSupabaseConfigured()) return;
    let cancelled = false;

    (async () => {
      const { data, error } = await supabase
        .from('watchlist')
        .select('anime_id')
        .eq('user_id', user.id);
      if (error) {
        console.error('Failed to load watchlist from Supabase', error);
        return;
      }
      if (cancelled) return;
      const ids = data.map((row: { anime_id: string }) => row.anime_id);
      setWatchlist(ids);
      setStoredList(WATCHLIST_KEY, ids);
    })();

    return () => {
      cancelled = true;
    };
  }, [user]);

  const toggleWatchlist = useCallback((animeId: string) => {
    setWatchlist(prev => {
      const inList = prev.includes(animeId);
      const next = inList ? prev.filter(id => id !== animeId) : [...prev, animeId];
      setStoredList(WATCHLIST_KEY, next);

      // Sincronizza con Supabase in background se possibile
      if (isSupabaseConfigured()) {
        (async () => {
          try {
            const sess = supabase.auth.getUser ? await supabase.auth.getUser() : null;
            const userId = sess?.data.user?.id;
            if (!userId) return;
            if (inList) {
              await supabase
                .from('watchlist')
                .delete()
                .eq('user_id', userId)
                .eq('anime_id', animeId);
            } else {
              await supabase
                .from('watchlist')
                .upsert({ user_id: userId, anime_id: animeId });
            }
          } catch (e) {
            console.error('Failed to sync watchlist with Supabase', e);
          }
        })();
      }

      return next;
    });
  }, []);

  const isInWatchlist = useCallback((animeId: string) => watchlist.includes(animeId), [watchlist]);

  return { watchlist, toggleWatchlist, isInWatchlist };
}

// ── Watched Episodes (episodi visti) ──
export function useWatchedEpisodes(animeId?: string) {
  const { user } = useAuth();
  const [watched, setWatched] = useState<Set<string>>(() => {
    if (!animeId) return new Set();
    const all = getStoredSet(WATCHED_KEY);
    return new Set(all[animeId] || []);
  });

  useEffect(() => {
    if (!animeId) { setWatched(new Set()); return; }

    // Carica stato locale
    const all = getStoredSet(WATCHED_KEY);
    setWatched(new Set(all[animeId] || []));

    // Carica anche da Supabase se disponibile
    if (!user || !isSupabaseConfigured()) return;
    let cancelled = false;
    (async () => {
      const { data, error } = await supabase
        .from('watched_episodes')
        .select('episode_id')
        .eq('user_id', user.id)
        .eq('anime_id', animeId);
      if (error) {
        console.error('Failed to load watched episodes from Supabase', error);
        return;
      }
      if (cancelled) return;
      const episodeIds = data.map((row: { episode_id: string }) => row.episode_id);
      const nextSet = new Set(episodeIds);
      setWatched(nextSet);
      const allLocal = getStoredSet(WATCHED_KEY);
      allLocal[animeId] = Array.from(nextSet);
      setStoredSet(WATCHED_KEY, allLocal);
    })();

    return () => { cancelled = true; };
  }, [animeId, user]);

  const toggleWatched = useCallback((episodeId: string, _seasonId: string) => {
    if (!animeId) return;
    setWatched(prev => {
      const next = new Set(prev);
      if (next.has(episodeId)) {
        next.delete(episodeId);
      } else {
        next.add(episodeId);
      }
      const all = getStoredSet(WATCHED_KEY);
      all[animeId] = Array.from(next);
      setStoredSet(WATCHED_KEY, all);

      // Aggiorna Supabase
      if (isSupabaseConfigured()) {
        (async () => {
          try {
            const sess = supabase.auth.getUser ? await supabase.auth.getUser() : null;
            const userId = sess?.data.user?.id;
            if (!userId) return;
            if (next.has(episodeId)) {
              await supabase
                .from('watched_episodes')
                .upsert({
                  user_id: userId,
                  anime_id: animeId,
                  season_id: _seasonId,
                  episode_id: episodeId,
                });
            } else {
              await supabase
                .from('watched_episodes')
                .delete()
                .eq('user_id', userId)
                .eq('anime_id', animeId)
                .eq('episode_id', episodeId);
            }
          } catch (e) {
            console.error('Failed to sync watched episodes with Supabase', e);
          }
        })();
      }

      return next;
    });
  }, [animeId]);

  const markWatched = useCallback((episodeId: string, _seasonId: string) => {
    if (!animeId) return;
    setWatched(prev => {
      if (prev.has(episodeId)) return prev;
      const next = new Set(prev);
      next.add(episodeId);
      const all = getStoredSet(WATCHED_KEY);
      all[animeId] = Array.from(next);
      setStoredSet(WATCHED_KEY, all);

      if (isSupabaseConfigured()) {
        (async () => {
          try {
            const sess = supabase.auth.getUser ? await supabase.auth.getUser() : null;
            const userId = sess?.data.user?.id;
            if (!userId) return;
            await supabase
              .from('watched_episodes')
              .upsert({
                user_id: userId,
                anime_id: animeId,
                season_id: _seasonId,
                episode_id: episodeId,
              });
          } catch (e) {
            console.error('Failed to mark watched episode in Supabase', e);
          }
        })();
      }

      return next;
    });
  }, [animeId]);

  const isWatched = useCallback((episodeId: string) => watched.has(episodeId), [watched]);

  return { watched, toggleWatched, markWatched, isWatched };
}
