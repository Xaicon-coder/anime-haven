import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";

export interface WatchProgress {
  animeId: string;
  seasonId: string;
  episodeId: string;
  currentTime: number;
  duration: number;
  updatedAt: number;
}

const STORAGE_KEY = "anistream-watch-progress";

function getAll(): Record<string, WatchProgress> {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
  } catch {
    return {};
  }
}

export function saveProgress(
  animeId: string,
  seasonId: string,
  episodeId: string,
  currentTime: number,
  duration: number
) {
  const all = getAll();
  const key = `${animeId}__${seasonId}__${episodeId}`;
  all[key] = { animeId, seasonId, episodeId, currentTime, duration, updatedAt: Date.now() };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

export function getProgress(animeId: string, seasonId: string, episodeId: string): WatchProgress | null {
  const all = getAll();
  return all[`${animeId}__${seasonId}__${episodeId}`] || null;
}

// Returns the most recent episode per anime, sorted by most recent
export function getContinueWatching(): WatchProgress[] {
  const all = getAll();
  const entries = Object.values(all);

  // Keep only the most recent per anime
  const byAnime = new Map<string, WatchProgress>();
  for (const entry of entries) {
    const existing = byAnime.get(entry.animeId);
    if (!existing || entry.updatedAt > existing.updatedAt) {
      // Skip if basically finished (within 60s of end)
      if (entry.duration > 0 && entry.currentTime < entry.duration - 60) {
        byAnime.set(entry.animeId, entry);
      }
    }
  }

  return Array.from(byAnime.values()).sort((a, b) => b.updatedAt - a.updatedAt);
}

// ==== Supabase integration for multi-device sync ====

export function useRemoteWatchProgress(userId: string | undefined | null) {
  const queryClient = useQueryClient();

  const query = useQuery({
    queryKey: ["watch_progress", userId],
    enabled: !!userId,
    queryFn: async () => {
      if (!userId) return [];
      const { data, error } = await supabase
        .from("watch_progress")
        .select("*")
        .eq("user_id", userId);
      if (error) throw error;
      return data as {
        anime_id: string;
        season_id: string;
        episode_id: string;
        current_time_seconds: number;
        duration_seconds: number;
        updated_at: string;
      }[];
    },
  });

  const mutation = useMutation({
    mutationKey: ["watch_progress_mutation", userId],
    mutationFn: async (payload: {
      animeId: string;
      seasonId: string;
      episodeId: string;
      currentTime: number;
      duration: number;
    }) => {
      if (!userId) return;
      const { error } = await supabase
        .from("watch_progress")
        .upsert(
          {
            user_id: userId,
            anime_id: payload.animeId,
            season_id: payload.seasonId,
            episode_id: payload.episodeId,
            current_time_seconds: Math.floor(payload.currentTime),
            duration_seconds: Math.floor(payload.duration),
          },
          { onConflict: "user_id,anime_id,season_id,episode_id" }
        );
      if (error) throw error;
    },
    onSuccess: () => {
      if (userId) {
        queryClient.invalidateQueries({ queryKey: ["watch_progress", userId] });
      }
    },
  });

  return {
    progress: query.data,
    isLoading: query.isLoading,
    error: query.error,
    saveRemoteProgress: mutation.mutate,
  };
}

export function mapRemoteProgressToLocal(
  remote: {
    anime_id: string;
    season_id: string;
    episode_id: string;
    current_time_seconds: number;
    duration_seconds: number;
    updated_at: string;
  }[]
): WatchProgress[] {
  return remote.map((r) => ({
    animeId: r.anime_id,
    seasonId: r.season_id,
    episodeId: r.episode_id,
    currentTime: r.current_time_seconds,
    duration: r.duration_seconds,
    updatedAt: new Date(r.updated_at).getTime(),
  }));
}
