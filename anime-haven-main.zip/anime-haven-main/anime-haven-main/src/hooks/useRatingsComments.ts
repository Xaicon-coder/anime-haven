import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";

export interface CommentItem {
  id: number;
  userId: string;
  username: string | null;
  content: string;
  createdAt: string;
}

export function useAnimeRating(animeId: string | undefined) {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["anime_rating", animeId],
    enabled: !!animeId && isSupabaseConfigured(),
    queryFn: async () => {
      if (!animeId) return null;
      const { data, error } = await supabase
        .from("ratings")
        .select("score")
        .eq("anime_id", animeId);
      if (error) throw error;
      if (!data || data.length === 0) return { average: null, count: 0, userScore: null };

      const scores = data.map((r) => r.score as number);
      const average = scores.reduce((a, b) => a + b, 0) / scores.length;

      let userScore: number | null = null;
      if (user?.id) {
        const mine = data.find((r: any) => r.user_id === user.id);
        if (mine) userScore = mine.score;
      }

      return { average, count: data.length, userScore };
    },
  });

  const mutation = useMutation({
    mutationKey: ["anime_rating_mutation", animeId],
    mutationFn: async (score: number) => {
      if (!user?.id || !animeId) return;
      const { error } = await supabase
        .from("ratings")
        .upsert({ user_id: user.id, anime_id: animeId, score });
      if (error) throw error;
    },
    onSuccess: () => {
      if (animeId) {
        queryClient.invalidateQueries({ queryKey: ["anime_rating", animeId] });
      }
    },
  });

  return {
    average: data?.average ?? null,
    count: data?.count ?? 0,
    userScore: data?.userScore ?? null,
    isLoading,
    setScore: mutation.mutate,
  };
}

export function useComments(animeId: string | undefined, episodeId?: string | null) {
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: ["comments", animeId, episodeId ?? "anime"],
    enabled: !!animeId && isSupabaseConfigured(),
    queryFn: async () => {
      if (!animeId) return [];
      let query = supabase
        .from("comments")
        .select("id, content, created_at, user_id, profiles(username)")
        .eq("anime_id", animeId)
        .is("parent_id", null)
        .order("created_at", { ascending: false });

      if (episodeId) {
        query = query.eq("episode_id", episodeId);
      } else {
        query = query.is("episode_id", null);
      }

      const { data, error } = await query;
      if (error) throw error;
      return (data || []).map((row: any) => ({
        id: row.id as number,
        userId: row.user_id as string,
        username: row.profiles?.username ?? null,
        content: row.content as string,
        createdAt: row.created_at as string,
      })) as CommentItem[];
    },
  });

  const createComment = useMutation({
    mutationKey: ["create_comment", animeId, episodeId ?? "anime"],
    mutationFn: async (content: string) => {
      if (!user?.id || !animeId) return;
      const payload: any = {
        user_id: user.id,
        anime_id: animeId,
        content,
      };
      if (episodeId) payload.episode_id = episodeId;
      const { error } = await supabase.from("comments").insert(payload);
      if (error) throw error;
    },
    onSuccess: () => {
      if (animeId) {
        queryClient.invalidateQueries({ queryKey: ["comments", animeId, episodeId ?? "anime"] });
      }
    },
  });

  return {
    comments: data ?? [],
    isLoading,
    canComment: !!user,
    addComment: createComment.mutate,
  };
}

